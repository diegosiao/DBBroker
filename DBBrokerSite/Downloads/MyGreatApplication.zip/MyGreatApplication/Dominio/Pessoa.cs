﻿using DBBroker.Mapping;
using System;
using System.Collections.Generic;

namespace MyGreatApplication.Dominio
{
    [DBMappedClass(Table="Pessoas", PrimaryKey="IdPessoa")]
    public class Pessoa
    {
        public int Id { get; set; }

        public string Nome { get; set; }

        public DateTime Nascimento { get; set; }

        [DBMappedTo(Column="Ordenado")]
        public decimal Salario { get; set; }

        [DBTransient]
        public bool IsLoggedIn { get; set; }

        public Endereco Endereco { get; set; }
                
        public Endereco EnderecoAnterior { get; set; }

        [DBReadOnly(DBDefaultValue="GETDATE()")]
        public DateTime Registro { get; set; }

        [DBMappedList(
            RelationshipTable="Pessoas_Carros",
            ParentColumnIds="IdPessoa",
            ChildrenColumnIds="IdCarro")]
        public List<Carro> Carros { get; set; }
    }
}
