﻿namespace MyGreatApplication.Dominio
{
    [DBBroker.Mapping.DBMappedClass(Table = "Enderecos", PrimaryKey = "IdEndereco")]
    public class Endereco
    {
        public int Id { get; set; }

        public string Descricao { get; set; }
    }
}
