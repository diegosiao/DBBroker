﻿namespace MyGreatApplication.Dominio
{
    [DBBroker.Mapping.DBMappedClass(Table = "Carros", PrimaryKey = "IdCarro")]
    public class Carro
    {
        public int Id { get; set; }

        public string Modelo { get; set; }
    }
}
