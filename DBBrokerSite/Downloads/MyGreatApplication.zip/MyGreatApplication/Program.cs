﻿using DBBroker.Engine;
using MyGreatApplication.Dominio;
using MyGreatApplication.Persistencia;
using System;
using System.Collections.Generic;

namespace MyGreatApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {

                /*  ATENÇÃO! Antes de executar essa aplicação...
                    ============================================
                    Adicione a referência ao DBBroker via NuGet
                    Se tiver alguma dúvida de como realizar essa referência, acesse:
                    http://www.getdbbroker.com/Home/InstallViaNuget
                 * 
                 *  Obrigado! 
                */

                // Criação do script dos objetos
                SqlScriptMaker script = new SqlScriptMaker();
                string sql = script.GetDatabaseScript();

                // Persitência transacional
                /* 
                Pessoa pessoa = DBPessoa.GetById(2);
                pessoa.Endereco = new Endereco()
                {
                    Descricao = "RUA DOS AVIADORES, 7955"
                };
                
                DBPessoa.SaveNewAddress(pessoa);
                */
                
                // Criptografia do arquivo de configuração (DBBroker.config)
                // Configuration.EncryptConfigFile();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);                
            }
        }
    }
}
