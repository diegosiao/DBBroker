﻿using DBBroker.Engine;
using MyGreatApplication.Dominio;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;

namespace MyGreatApplication.Persistencia
{
    class DBPessoa : DBBroker<Pessoa>
    {
        internal static List<Pessoa> GetByNome(string nome)
        {
            return ExecCmdSQL(
                cmdText: "SELECT * FROM Pessoas WHERE Nome LIKE '%' + @Nome + '%'"
                , parameters: new List<DbParameter>() { new SqlParameter("@Nome", nome) });
        }

        internal static void SaveNewAddress(Pessoa pessoa)
        {
            List<DbParameter> parametros = new List<DbParameter>();
            parametros.Add(new SqlParameter("@IdPessoa", pessoa.Id));

            DbTransaction transacao = GetTransaction();

            try
            {
                DBEndereco.Save(pessoa.Endereco, transacao);
                parametros.Add(new SqlParameter("@IdEndereco", pessoa.Endereco.Id));

                ExecCmdSQL(
                    cmdText: @" UPDATE Pessoas
                            SET IdEndereco = @IdEndereco,
                                IdEnderecoAnterior = IdEndereco,
                                Nome += ' [Endereço Alterado]'
                            WHERE IdPessoa = @IdPessoa; ",
                    parameters: parametros,
                    transaction: transacao);

                transacao.Commit();
            }
            catch (Exception ex)
            {
                if (transacao.Connection != null)
                    transacao.Rollback();
                throw ex;
            }
        }
    }
}
