﻿using DBBroker.Engine;
using MyGreatApplication.Dominio;
using System;
using System.Collections.Generic;

namespace MyGreatApplication.Persistencia
{
    class DBCarro : DBBroker<Carro>
    {
    }
}
